# FMX menus on Linux: the problem and the fix

Instructions for Claude, working on any Delphi FireMonkey (FMX) program that
has a menu bar and runs on Linux. Read all of this before writing menu code.
It records what was found while fixing GDEMFetch
(<https://github.com/peardox/GDEM>, `GDEMFetch/ui/MainForm.pas`,
`TfrmMain.UseFmxMenuBar`) in October 2026, with Delphi 13 on Ubuntu (GTK 3),
so the same mistakes are not made again.

## Summary

- On Linux, FMX shows a form's `TMainMenu` as a native GTK menu bar, and that
  bar shows **only the first letter** of each menu and item ("F D V" instead
  of "File Data View").
- The cure is to show the menus on an FMX **`TMenuBar`** instead, which FMX
  draws itself in the program's style.
- **How** the menus get onto the `TMenuBar` matters. Two obvious ways fail:
  one crashes, and the other leaves the native bar showing. Only the method
  below works.

## What happens, step by step

1. **Plain `TMainMenu`:** the native GTK bar shows one letter per menu, and
   the submenus show one letter per item.

2. **Move the items onto a `TMenuBar`, then free the `TMainMenu`:** this is
   what Sprite3D did first. It can crash at start-up before any window
   appears:

   ```
   Exception EAccessViolation in module libgobject-2.0.so.0 ...
   Access violation at address ..., accessing address 0000000000000000.
   ```

   The stack trace starts in `g_type_check_instance_is_fundamentally_a`,
   called from `g_object_ref`. With Skia turned off, the same fault showed as
   **Runtime error 217**. A program that changes few menu items may not
   crash, but its terminal output at start-up then shows:

   ```
   GLib-GObject-CRITICAL **: g_object_ref: assertion 'G_IS_OBJECT (object)' failed
   GLib-GObject-CRITICAL **: g_object_get_data: assertion 'G_IS_OBJECT (object)' failed
   Gtk-CRITICAL **: gtk_menu_item_get_label: assertion 'GTK_IS_MENU_ITEM (menu_item)' failed
   Gtk-CRITICAL **: gtk_menu_item_set_label: assertion 'GTK_IS_MENU_ITEM (menu_item)' failed
   Gtk-CRITICAL **: gtk_widget_show: assertion 'GTK_IS_WIDGET (widget)' failed
   GLib-GObject-CRITICAL **: g_object_unref: assertion 'G_IS_OBJECT (object)' failed
   ```

   That is the same bug, just not fatal this time.

3. **Copy the items onto a `TMenuBar`, then free the `TMainMenu` with its
   items still in it:** no crash, and the FMX bar works. But the native GTK
   bar stays above it, still showing the first letters.

4. **Copy the items, free the original items one by one, then free the
   `TMainMenu`:** this works, with one menu bar showing full names and no
   GTK warnings.

## Why

- By the time the form's `OnCreate` runs, FMX has already built the native
  GTK menu from the `TMainMenu`. Each `TMenuItem` keeps a handle to its GTK
  widget.
- Freeing the `TMainMenu` destroys those GTK widgets. An item that was
  **moved** elsewhere first keeps its handle, which now points at a
  destroyed widget. The next change to one of its properties (`Enabled`,
  `IsChecked`, `Text`, `Visible`) makes FMX update that dead widget, and
  GTK either warns or crashes.
- Freeing a `TMainMenu` with items still in it does not make FMX rebuild the
  GTK bar, so the bar stays on screen. Removing items one at a time does
  make FMX rebuild the bar after each removal; once empty, the bar goes.
- So the items shown on the new bar must be **new objects that GTK has never
  seen**. The originals must be **removed one by one** while the
  `TMainMenu` still exists.

## The fix

1. Create a `TMenuBar`, aligned to the top of the form.
2. Copy every item of the `TMainMenu`, with its submenus, onto the bar. Copy
   the properties the program uses and the `OnClick` handler. Each copy must
   be **owned by the same component as the original**, normally the form.
3. Free the original top-level items **one at a time** while the `TMainMenu`
   still exists. Then call `RecreateOSMenu`, and free the `TMainMenu`.
4. Give each copy **its original's `Name`**. When a component owned by the
   form is named, Delphi's `TComponent.SetReference` points the form's
   published field of that name at it. So `mnuShowGrid` and the like now
   refer to the copies, and every handler and `IsChecked` test in the form
   works unchanged.
   - This must happen after step 3. When each original is freed, Delphi sets
     its field to nil and its name becomes free to use.

### A reusable unit

This is a drop-in version of GDEMFetch's tested method, made general.
Treat it as untested until the basic test below passes. Add it to the
project and call it as shown.

```pascal
{ @abstract(Shows a form's main menu on Linux with an FMX menu bar instead
  of GTK's.)

  On Linux FMX shows a TMainMenu as a native GTK menu bar, which shows only
  the first letter of each menu and item. @link(ReplaceMainMenu) puts copies
  of the menus on an FMX TMenuBar and removes the TMainMenu in a way that
  neither leaves GTK's bar showing nor leaves items pointing at destroyed
  GTK widgets. On other platforms it does nothing. }
unit FmxLinuxMenu;

interface

uses
  FMX.Forms, FMX.Menus;

{ Replaces a form's TMainMenu with an FMX TMenuBar, on Linux only. Call it
  first thing in the form's OnCreate, before any code changes a menu item or
  adds items at run time.

  Every item is copied with its submenus: Text, Enabled, Visible, AutoCheck,
  IsChecked, RadioItem, GroupIndex, ShortCut, Tag and OnClick. Add any other
  property the program uses to CopyItem. Each copy is then given its
  original's name, which points the form's published field at it, so code
  that uses those fields carries on working. References to the original
  items kept anywhere else (private fields, lists, TagObject) are left
  pointing at freed objects, so do not take any before calling this.
  @param(AForm The form the menu bar goes on.)
  @param(AMenu The form's TMainMenu, usually its published field. It is
    freed and set to nil.)
  @returns(The new menu bar, owned by AForm; nil on other platforms, or if
    AMenu is nil.) }
function ReplaceMainMenu(AForm: TCommonCustomForm; var AMenu: TMainMenu): TMenuBar;

implementation

uses
  System.SysUtils, System.Classes, FMX.Types;

{$IF defined(LINUX) and not defined(ANDROID)}
function ReplaceMainMenu(AForm: TCommonCustomForm; var AMenu: TMainMenu): TMenuBar;
var
  LOwner: TComponent;
  LCopies: TArray<TMenuItem>;
  LNames: TArray<string>;
  LIndex: Integer;

  { Copies a menu item and its submenus onto a new parent, noting the
    original's name for later.
    @param(AItem The item to copy.)
    @param(AParent The menu bar or menu item the copy goes in.) }
  procedure CopyItem(AItem: TMenuItem; AParent: TFmxObject);
  var
    LCopy: TMenuItem;
    LSub: Integer;
  begin
    // Owned like the original, so naming it later sets the owner's field
    LCopy := TMenuItem.Create(LOwner);
    LCopy.Text := AItem.Text;
    LCopy.Enabled := AItem.Enabled;
    LCopy.Visible := AItem.Visible;
    LCopy.AutoCheck := AItem.AutoCheck;
    LCopy.IsChecked := AItem.IsChecked;
    LCopy.RadioItem := AItem.RadioItem;
    LCopy.GroupIndex := AItem.GroupIndex;
    LCopy.ShortCut := AItem.ShortCut;
    LCopy.Tag := AItem.Tag;
    LCopy.OnClick := AItem.OnClick;
    LCopy.Parent := AParent;
    LCopies := LCopies + [LCopy];
    LNames := LNames + [AItem.Name];
    for LSub := 0 to AItem.ItemsCount - 1 do
      CopyItem(AItem.Items[LSub], LCopy);
  end;

begin
  Result := nil;
  if AMenu = nil then
    Exit;
  LOwner := AMenu.Owner;
  if LOwner = nil then
    LOwner := AForm;

  Result := TMenuBar.Create(AForm);
  Result.Parent := AForm;
  // Top-aligned controls are laid out in the order of their positions, so
  // this puts the menu bar above any toolbar already aligned to the top
  Result.Position.Y := -1;
  Result.Align := TAlignLayout.Top;
  for LIndex := 0 to AMenu.ItemsCount - 1 do
    if AMenu.Items[LIndex] is TMenuItem then
      CopyItem(TMenuItem(AMenu.Items[LIndex]), Result);

  // Empty the TMainMenu item by item: each removal makes FMX rebuild the GTK
  // menu bar without that item, so it ends up empty and goes. Freeing the
  // TMainMenu with items still in it leaves GTK's bar showing. Each
  // original's field on the form is set to nil as it is freed.
  while AMenu.ItemsCount > 0 do
    AMenu.Items[0].Free;
  AMenu.RecreateOSMenu;
  FreeAndNil(AMenu);

  // Naming a copy points the owner's field of that name at it
  for LIndex := 0 to High(LCopies) do
    if LNames[LIndex] <> '' then
      LCopies[LIndex].Name := LNames[LIndex];
end;
{$ELSE}
function ReplaceMainMenu(AForm: TCommonCustomForm; var AMenu: TMainMenu): TMenuBar;
begin
  Result := nil;
end;
{$ENDIF}

end.
```

Calling it, first thing in the form's `OnCreate`:

```pascal
procedure TfrmMain.FormCreate(Sender: TObject);
begin
  // Linux: FMX's own menu bar instead of GTK's, which shows only first
  // letters. Must come before anything that touches the menu items.
  FMenuBar := ReplaceMainMenu(Self, mnuMain);
  ...
end;
```

`FMenuBar` is a private `TMenuBar` field, which stays nil on other
platforms; it can be left out if nothing needs the bar. The form's unit
needs `FmxLinuxMenu` and `FMX.Menus` in its `uses`.

## Rules for a program with a menu

1. **Swap first.** Call the replacement first thing in `OnCreate`, before
   any code changes a menu item, adds items at run time, or stores a
   reference to an item.
2. **Reach designed items only through the form's published fields** (the
   names the designer gives them). After the swap those fields point at the
   copies. Never keep a reference to a designed item from before the swap:
   in a private field, a list, an array, `TagObject`, a closure, anything.
   That object is freed by the swap.
3. **Add run-time items after the swap**, parented through published fields
   (`ViewMenu.AddObject(Item)`, `FileMenu.InsertObject(...)`). They then go
   straight onto the FMX bar, and GTK never sees them. Keeping them in
   private fields is fine.
4. **Copy every property the program uses.** The unit copies the common
   ones. If items use `Bitmap`, `ImageIndex`, `StyleLookup`, `Hint`,
   `Action`, `TagObject`, `TagString` or another event, add them to
   `CopyItem`. To check, list the properties set under `TMenuItem` objects
   in the form's `.fmx`.
5. **Every form with a `TMainMenu` needs the swap**, not only the main
   form. Popup menus (`TPopupMenu`) were not part of this work: check them
   on Linux too.
6. **Top-aligned controls:** FMX lays out controls with the same `Align` in
   the order of their positions. `Position.Y := -1` before
   `Align := TAlignLayout.Top` keeps the menu bar above a toolbar or other
   top-aligned control.
7. **Linux only.** Guard Linux-only code with
   `{$IF defined(LINUX) and not defined(ANDROID)}`. Windows and macOS keep
   their native menus: the Windows bar and the macOS system menu bar are
   fine.
8. **Never "fix" a crash or warning here by moving the original items, or
   by freeing the `TMainMenu` without emptying it first.** Those are the two
   failures above.

## How to check it on Linux

Run the program **from a terminal**, not only from the IDE, so GTK's
warnings can be seen, and check that:

- one menu bar shows full names, with no bar of single letters above it;
- the terminal shows **no** `GLib-GObject-CRITICAL` or `Gtk-CRITICAL` lines
  at start-up, nor when using the menus;
- every menu and submenu opens with full item names;
- clicking items runs their handlers;
- `AutoCheck` items tick and untick, and radio items move the tick within
  their group;
- items disabled or enabled by code grey out and come back;
- keyboard shortcuts still work;
- changing the theme or style, if the program can, restyles the menu bar;
- on Windows and macOS the menus are unchanged.

## A basic test program, before touching a real application

Build this first, to prove the unit works on the Linux machine.

- **Form:** a `TMainMenu` named `mnuMain` with:
  - **File:** `mnuHello` ("Say Hello"), a separator, `mnuExit` ("Exit");
  - **View:** `mnuGrid` ("Show Grid", `AutoCheck` on, `IsChecked` on), and a
    submenu `mnuSize` ("Size") holding `mnuSmall`, `mnuMedium` and
    `mnuLarge`, all `RadioItem` with `GroupIndex` 1, Medium checked.
- **Other controls:** a `TLayout` aligned to the top holding a `TLabel`,
  standing in for a toolbar, and a `TMemo` aligned to the client area that
  logs every click with the item's `Text` and, for checkable items,
  `IsChecked`.
- **`OnCreate`:**
  1. `FMenuBar := ReplaceMainMenu(Self, mnuMain);`
  2. Then, deliberately, the kind of changes that crashed GDEMFetch:
     `mnuHello.Enabled := False;`, `mnuGrid.IsChecked := False;` and
     `mnuHello.Text := 'Say Hello (wait)';`.
- **A `TTimer`:** after 3 seconds it sets `mnuHello.Enabled := True` and
  `mnuHello.Text := 'Say Hello'`, then stops. This shows that changes made
  after start-up reach the copies.
- **Optional:** add a compile-time switch that uses the old move-and-free
  method instead (move the items to the bar, then `FreeAndNil(mnuMain)`), to
  confirm the test reproduces the crash or the GTK warnings. That proves the
  test is a real one.

Pass when every item on the checklist above holds. In particular: the
terminal stays free of GTK warnings, the bar under the menu shows full
names, "Say Hello" starts greyed and comes back after 3 seconds, and the
grid and size ticks work.
